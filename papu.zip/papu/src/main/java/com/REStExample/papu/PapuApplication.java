package com.REStExample.papu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PapuApplication {

	public static void main(String[] args) {
		SpringApplication.run(PapuApplication.class, args);
	}
}
